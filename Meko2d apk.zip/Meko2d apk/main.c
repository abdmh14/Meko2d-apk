#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

// Fix TCC missing 64-bit integer limits errors
#ifndef _I64_MAX
#define _I64_MAX   9223372036854775807i64
#endif
#ifndef _I64_MIN
#define _I64_MIN   (-9223372036854775807i64 - 1i64)
#endif
#ifndef _UI64_MAX
#define _UI64_MAX  18446744073709551615ui64
#endif

// Fix TCC missing Windows GDI Font constants errors
#ifndef OUT_OUTLINE_PRECISION
#define OUT_OUTLINE_PRECISION 8
#endif
#ifndef CLIP_BOUNDS_PRECISION
#define CLIP_BOUNDS_PRECISION 16
#endif
#ifndef CLEAN_TEXT_QUALITY
#define CLEAN_TEXT_QUALITY 4
#endif

#define LUA_IMPL
#include "minilua.h"

char globalLuaPath[MAX_PATH] = {0};
char currentExeName[MAX_PATH] = {0};
char detectedFolderName[MAX_PATH] = {0};
BOOL isApplicationMode = FALSE; 
BOOL hasLuaScript = FALSE; 
lua_State *L = NULL;
HDC hdcBuffer = NULL; 

static int Meko_C_DrawRect(lua_State *LState) {
    int rx = (int)lua_tonumber(LState, 1);
    int ry = (int)lua_tonumber(LState, 2);
    int rw = (int)lua_tonumber(LState, 3);
    int rh = (int)lua_tonumber(LState, 4);
    
    uint32_t finalRectColor = (((int)lua_tonumber(LState, 5)) << 16) | 
                              (((int)lua_tonumber(LState, 6)) << 8)  | 
                               ((int)lua_tonumber(LState, 7));

    if (hdcBuffer) {
        HBRUSH brush = CreateSolidBrush(RGB((finalRectColor >> 16) & 0xFF, (finalRectColor >> 8) & 0xFF, finalRectColor & 0xFF));
        RECT rect = { rx, ry, rx + rw, ry + rh };
        FillRect(hdcBuffer, &rect, brush);
        DeleteObject(brush);
    }
    return 0;
}

static int Meko_C_IsKeyPressed(lua_State *LState) {
    int vkCode = (int)lua_tonumber(LState, 1);
    if (GetAsyncKeyState(vkCode) & 0x8000) lua_pushboolean(LState, 1);
    else lua_pushboolean(LState, 0);
    return 1;
}

void InitLuaEngine() {
    L = luaL_newstate();
    if (!L) return;
    luaL_openlibs(L);
    lua_register(L, "Meko_C_DrawRect", Meko_C_DrawRect);
    lua_register(L, "Meko_C_IsKeyPressed", Meko_C_IsKeyPressed);
    luaL_dofile(L, globalLuaPath);
}

// دالة تفاعلية دقيقة تبحث عن أي ملف ينتهي بامتداد .lua داخل المجلد المحدد
BOOL FindAnyLuaScriptInFolder(const char* folder_path, char* out_script_path) {
    WIN32_FIND_DATAA findData;
    char searchFilter[MAX_PATH];
    snprintf(searchFilter, sizeof(searchFilter), "%s\\*.lua", folder_path);
    
    HANDLE hFind = FindFirstFileA(searchFilter, &findData);
    if (hFind != INVALID_HANDLE_VALUE) {
        snprintf(out_script_path, MAX_PATH, "%s\\%s", folder_path, findData.cFileName);
        FindClose(hFind);
        return TRUE;
    }
    return FALSE;
}

// التحديث السحري: ميكانيكية مسح شامل وتصدير كل مجلد باسمه الصحيح والمطابق 100%
void ScanAndExportAllFolders(const char* base_path, const char* current_exe_full_path) {
    WIN32_FIND_DATAA findData;
    char searchPath[MAX_PATH];
    snprintf(searchPath, sizeof(searchPath), "%s*", base_path);
    
    HANDLE hFind = FindFirstFileA(searchPath, &findData);
    if (hFind == INVALID_HANDLE_VALUE) return;
    
    int exportCount = 0;
    do {
        if (strcmp(findData.cFileName, ".") == 0 || strcmp(findData.cFileName, "..") == 0)
            continue;
            
        if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            char fullFolderPath[MAX_PATH];
            snprintf(fullFolderPath, sizeof(fullFolderPath), "%s%s", base_path, findData.cFileName);
            
            char dummyPath[MAX_PATH];
            if (FindAnyLuaScriptInFolder(fullFolderPath, dummyPath)) {
                char targetExeFullPath[MAX_PATH];
                // صنع ملف EXE يطابق اسم المجلد الحالي بالضبط!
                snprintf(targetExeFullPath, sizeof(targetExeFullPath), "%s%s.exe", base_path, findData.cFileName);
                CopyFileA(current_exe_full_path, targetExeFullPath, FALSE);
                exportCount++;
            }
        }
    } while (FindNextFileA(hFind, &findData));
    
    FindClose(hFind);
    
    if (exportCount > 0) {
        MessageBoxA(NULL, "Meko2D Smart Exporter: All components generated matching their folders!", "Meko2D Framework", MB_ICONINFORMATION);
    }
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    if (uMsg == WM_DESTROY) {
        if (L) lua_close(L);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    char exePath[MAX_PATH];
    GetModuleFileNameA(NULL, exePath, MAX_PATH);
    
    char *exeName = strrchr(exePath, '\\');
    if (exeName != NULL) {
        strncpy(currentExeName, exeName + 1, sizeof(currentExeName));
        if (stricmp(currentExeName, "Meko2d.exe") != 0) {
            isApplicationMode = TRUE;
            char folderTarget[MAX_PATH];
            strncpy(folderTarget, currentExeName, sizeof(folderTarget));
            char *dot = strrchr(folderTarget, '.');
            if (dot) *dot = '\0';
            strncpy(detectedFolderName, folderTarget, sizeof(detectedFolderName));
        }
        *(exeName + 1) = '\0';
    }
    
    SetCurrentDirectoryA(exePath);
    
    if (isApplicationMode) {
        char fullFolderPath[MAX_PATH];
        snprintf(fullFolderPath, sizeof(fullFolderPath), "%s%s", exePath, detectedFolderName);
        if (FindAnyLuaScriptInFolder(fullFolderPath, globalLuaPath)) {
            hasLuaScript = TRUE;
            InitLuaEngine();
        }
    } else {
        char currentExeFullPath[MAX_PATH];
        GetModuleFileNameA(NULL, currentExeFullPath, MAX_PATH);
        // تشغيل ميكانيكية التصدير الذكية والمطابقة لكل مجلد باسمه الصحيح
        ScanAndExportAllFolders(exePath, currentExeFullPath);
        return 0; // يغلق المانجر بعد التصدير الذكي للأنظمة
    }

    const char CLASS_NAME[] = "Meko2D_Framework";
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hIcon = (HICON)LoadImageA(NULL, "Meko.ico", IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(0, CLASS_NAME, isApplicationMode ? "Meko2D Live Environment" : "Meko2D Framework Console", 
        WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, 800, 600, NULL, NULL, hInstance, NULL);

    SetTimer(hwnd, 1, 16, NULL);

    MSG msg = {0};
    while (GetMessage(&msg, NULL, 0, 0)) {
        if (msg.message == WM_TIMER) {
            if (isApplicationMode && hasLuaScript && L) {
                lua_getglobal(L, "Meko_Update");
                if (lua_isfunction(L, -1)) lua_pcall(L, 0, 0, 0);
                else lua_pop(L, 1);
            }

            HDC hdc = GetDC(hwnd);
            RECT rect; GetClientRect(hwnd, &rect);
            HDC memDC = CreateCompatibleDC(hdc);
            HBITMAP memBM = CreateCompatibleBitmap(hdc, rect.right, rect.bottom);
            SelectObject(memDC, memBM);

            HBRUSH bg = CreateSolidBrush(RGB(12, 12, 16));
            FillRect(memDC, &rect, bg); 
            DeleteObject(bg);

            hdcBuffer = memDC;
            
            if (isApplicationMode && hasLuaScript && L) {
                lua_getglobal(L, "Meko_Draw");
                if (lua_isfunction(L, -1)) lua_pcall(L, 0, 0, 0);
                else lua_pop(L, 1);
            } else {
                SetTextColor(memDC, RGB(0, 180, 255));
                SetBkMode(memDC, TRANSPARENT);
                HFONT font = CreateFontA(44, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECISION, CLIP_BOUNDS_PRECISION, CLEAN_TEXT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Consolas");
                SelectObject(memDC, font);
                RECT textRect = { 0, 0, rect.right, rect.bottom };
                DrawTextA(memDC, "meko2d framework", -1, &textRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                DeleteObject(font);
            }
            
            hdcBuffer = NULL;
            BitBlt(hdc, 0, 0, rect.right, rect.bottom, memDC, 0, 0, SRCCOPY);
            DeleteObject(memBM); DeleteDC(memDC); ReleaseDC(hwnd, hdc);
        }
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}
